from django.apps import AppConfig


class AlunoConfig(AppConfig):
    name = 'aluno'
