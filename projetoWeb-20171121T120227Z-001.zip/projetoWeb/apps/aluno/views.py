from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def avisos(request):
	return render(request, 'avisos.html')

def atividades(request):
	return render(request, 'atividades.html')

def boletim(request):
	return render(request, 'boletim.html')
	
def alterarCadastro(request):
	return render(request, 'alterarCadastro.html')

def exercicios(request):
	return render(request, 'exercicios.html')
	
def entregaPendentes(request):
	return render(request, 'entregaAluno.html')
def ementas(request):
	return render(request, 'ementas.html')
def planoEnsino(request):
	return render(request, 'planoEnsino.html')
def forum(request):
	return render(request, 'forum.html')
def verforum(request):
	return render(request, 'verforum.html')
def testeaberto(request):
	return render(request, 'testeaberto.html')
def testeassociacao(request):
	return render(request, 'testeassociacao.html')
def testemulti(request):
	return render(request, 'testemulti.html')
def testeVF(request):
	return render(request, 'testeVF.html')
def mensagens(request):
	return render(request, 'mensagens.html')