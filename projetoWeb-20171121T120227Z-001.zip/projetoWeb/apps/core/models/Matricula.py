from django.db import models

class Matricula(models.Model):
    ra_aluno = models.IntegerField(primary_key=True)
    nome_disciplina = models.CharField(max_length=50)
    ano_ofertado = models.SmallIntegerField()
    semestre_ofertado = models.CharField(max_length=1)
    id_turma = models.CharField(max_length=1)

    class Meta:
        managed = False
        db_table = 'matricula'
        unique_together = (('ra_aluno', 'nome_disciplina', 'ano_ofertado', 'semestre_ofertado', 'id_turma'),)

