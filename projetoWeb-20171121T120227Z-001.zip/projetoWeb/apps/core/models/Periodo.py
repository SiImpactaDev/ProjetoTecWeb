
from django.db import models

class Periodo(models.Model):
    sigla_curso = models.CharField(primary_key=True, max_length=5)
    ano_grade = models.SmallIntegerField()
    semestre_grade = models.CharField(max_length=1)
    numero = models.AutoField()

    class Meta:
        managed = False
        db_table = 'periodo'
        unique_together = (('sigla_curso', 'ano_grade', 'semestre_grade', 'numero'),)
       