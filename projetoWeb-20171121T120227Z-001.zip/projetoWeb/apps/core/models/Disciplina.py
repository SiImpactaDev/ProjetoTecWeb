from django.db import models

class Diciplina(models.Model):
    nome = models.CharField(max_length=50)
    carga_horaria = models.IntegerField(blank=True, null=True)
    teoria = models.DecimalField(max_digits=3, decimal_places=2, blank=True, null=True)
    pratica = models.DecimalField(max_digits=3, decimal_places=2, blank=True, null=True)
    ementa = models.CharField(max_length=200, blank=True, null=True)
    competencias = models.CharField(max_length=200, blank=True, null=True)
    habilidades = models.CharField(max_length=200, blank=True, null=True)
    conteudo = models.CharField(max_length=200, blank=True, null=True)
    bibliografia_basica = models.CharField(max_length=200, blank=True, null=True)
    bibliografia_complementar = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'diciplina'
        unique_together = (('id', 'nome'),)
