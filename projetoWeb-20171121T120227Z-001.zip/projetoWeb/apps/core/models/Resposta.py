from django.db import models

class Turma(models.Model):
    nome_disciplina = models.CharField(primary_key=True, max_length=50)
    ano_ofertado = models.SmallIntegerField()
    semestre_ofertado = models.CharField(max_length=1)
    id = models.CharField(max_length=1)
    turno = models.CharField(max_length=15, blank=True, null=True)
    ra_professor = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'turma'
        unique_together = (('nome_disciplina', 'ano_ofertado', 'semestre_ofertado', 'id'),)

