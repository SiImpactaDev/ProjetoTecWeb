from django.db import models

class Professor(models.Model):
    ra = models.AutoField(primary_key=True)
    apelido = models.CharField(unique=True, max_length=30)
    nome = models.CharField(max_length=50, blank=True, null=True)
    email = models.CharField(max_length=60, blank=True, null=True)
    celular = models.CharField(max_length=11, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'professor'