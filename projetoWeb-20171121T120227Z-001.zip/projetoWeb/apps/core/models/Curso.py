from django.db import models

class Curso(models.Model):
    id = models.AutoField()
    sigla = models.CharField(primary_key=True, max_length=5)
    nome = models.CharField(unique=True, max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'curso'
        unique_together = (('sigla', 'id'),)

