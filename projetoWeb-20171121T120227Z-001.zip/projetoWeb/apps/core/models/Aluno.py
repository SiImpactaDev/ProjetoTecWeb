from django.db import models

class Aluno(models.Model):
    ra = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=50, blank=True, null=True)
    email = models.CharField(max_length=60, blank=True, null=True)
    celular = models.CharField(max_length=11, blank=True, null=True)
    sigla_curso = models.CharField(max_length=5, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'aluno'
