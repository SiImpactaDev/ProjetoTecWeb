
from django.db import models

class Questao(models.Model):
    nome_disciplina = models.CharField(primary_key=True, max_length=50)
    ano_ofertado = models.SmallIntegerField()
    semestre_ofertado = models.CharField(max_length=1)
    id_turma = models.CharField(max_length=1)
    numero = models.IntegerField()
    data_limite_entrega = models.DateField(blank=True, null=True)
    descricao = models.CharField(max_length=200, blank=True, null=True)
    data = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'questao'
        unique_together = (('nome_disciplina', 'ano_ofertado', 'semestre_ofertado', 'id_turma', 'numero'),)