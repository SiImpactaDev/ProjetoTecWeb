from django.db import models

class Periododiciplina(models.Model):
    sigla_curso = models.CharField(primary_key=True, max_length=5)
    ano_grade = models.SmallIntegerField()
    semestre_grade = models.CharField(max_length=1)
    numero_periodo = models.IntegerField()
    nome_diciplina = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'periododiciplina'
        unique_together = (('sigla_curso', 'ano_grade', 'semestre_grade', 'numero_periodo', 'nome_diciplina'),)
