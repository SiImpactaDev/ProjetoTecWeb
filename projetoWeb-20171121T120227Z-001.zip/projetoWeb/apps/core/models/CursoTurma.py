from django.db import models

class Cursoturma(models.Model):
    sigla_curso = models.CharField(primary_key=True, max_length=5)
    nome_disciplina = models.CharField(max_length=50)
    ano_ofertado = models.SmallIntegerField()
    semestre_ofertado = models.CharField(max_length=1)
    id_turma = models.CharField(max_length=1)

    class Meta:
        managed = False
        db_table = 'cursoturma'
        unique_together = (('sigla_curso', 'nome_disciplina', 'ano_ofertado', 'semestre_ofertado', 'id_turma'),)


