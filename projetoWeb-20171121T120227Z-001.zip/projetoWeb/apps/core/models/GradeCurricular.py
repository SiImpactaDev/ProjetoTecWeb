from django.db import models

class Gradecurricular(models.Model):
    sigla_curso = models.CharField(max_length=5)
    ano = models.SmallIntegerField(primary_key=True)
    semestre = models.CharField(max_length=1)

    class Meta:
        managed = False
        db_table = 'gradecurricular'
        unique_together = (('ano', 'semestre', 'sigla_curso'),)
       