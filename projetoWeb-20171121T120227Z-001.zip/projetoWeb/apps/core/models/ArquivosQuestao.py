
from django.db import models

class Arquivosquestao(models.Model):
    nome_disciplina = models.CharField(primary_key=True, max_length=50)
    ano_ofertado = models.SmallIntegerField()
    semestre_ofertado = models.CharField(max_length=1)
    id_turma = models.CharField(max_length=1)
    numero_questao = models.IntegerField()
    arquivo = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'arquivosquestao'
        unique_together = (('nome_disciplina', 'ano_ofertado', 'semestre_ofertado', 'id_turma', 'numero_questao', 'arquivo'),)
