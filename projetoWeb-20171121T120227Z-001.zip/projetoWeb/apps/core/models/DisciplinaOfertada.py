from django.db import models

class Disciplinaofertada(models.Model):
    nome_disciplina = models.CharField(primary_key=True, max_length=50)
    ano = models.SmallIntegerField()
    semestre = models.CharField(max_length=1)

    class Meta:
        managed = False
        db_table = 'disciplinaofertada'
        unique_together = (('nome_disciplina', 'ano', 'semestre'),)