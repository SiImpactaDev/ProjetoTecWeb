from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse,  Http404
# Create your views here.

from apps.core.models import Aluno

def index(request):
	alunos = Aluno
	context = {
        'user' : alunos
    }
	return render(request, 'Home/index.html', context)